<?php

class Calculator {
	public function add($string){
		return 0;
	}
}